@{
    my_custom_fact = 'value'
    my_complex_custom_fact = @{
        hello = 'world'
    }
}
